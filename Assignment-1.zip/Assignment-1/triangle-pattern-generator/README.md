# Triangle Pattern Generator

This repository contains a Python-based command-line application to generate three types of triangle patterns using the `*` character:

- Lower Triangular Pattern  
- Upper Triangular Pattern  
- Pyramid Pattern  
This assignment was created as part of the internship evaluation at **Celebal Technologies**.
