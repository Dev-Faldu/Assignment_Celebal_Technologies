from .patterns import lower_triangle, upper_triangle, pyramid
